#!/bin/bash

# Parameters
#SBATCH --array=0-8%9
#SBATCH --cpus-per-task=16
#SBATCH --error=/scratch/hpc-prf-intexml/jbecktepe/git_repos/arlbench/results/smac/sac_ant/0/42/.submitit/%A_%a/%A_%a_0_log.err
#SBATCH --gres=gpu:a100:1
#SBATCH --job-name=run_arlbench
#SBATCH --mem=16GB
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --open-mode=append
#SBATCH --output=/scratch/hpc-prf-intexml/jbecktepe/git_repos/arlbench/results/smac/sac_ant/0/42/.submitit/%A_%a/%A_%a_0_log.out
#SBATCH --partition=gpu
#SBATCH --signal=USR2@120
#SBATCH --time=240
#SBATCH --wckey=submitit

# setup
export JAX_PLATFORM_NAME=gpu

# command
export SUBMITIT_EXECUTOR=slurm
srun --unbuffered --output /scratch/hpc-prf-intexml/jbecktepe/git_repos/arlbench/results/smac/sac_ant/0/42/.submitit/%A_%a/%A_%a_%t_log.out --error /scratch/hpc-prf-intexml/jbecktepe/git_repos/arlbench/results/smac/sac_ant/0/42/.submitit/%A_%a/%A_%a_%t_log.err /scratch/hpc-prf-intexml/jbecktepe/.conda/envs/arlb/bin/python -u -m submitit.core._submit /scratch/hpc-prf-intexml/jbecktepe/git_repos/arlbench/results/smac/sac_ant/0/42/.submitit/%j
